export default function Home() {
  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h1>Welcome to Tune A Living</h1>
      <p>Elegant interiors crafted with precision and creativity.</p>
    </div>
  );
}