export default function Services() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">Our Services</h1>
      <ul className="mt-4 list-disc pl-6">
        <li>Gypsum Installations</li>
        <li>Cabinetry Work</li>
        <li>Painting & Tiling</li>
        <li>Custom Interior Design</li>
      </ul>
    </div>
  );
}
