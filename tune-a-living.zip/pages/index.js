export default function Home() {
  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold">Tune A Living</h1>
      <p className="mt-4">Welcome to Tune A Living — interior design tailored to your lifestyle.</p>
    </div>
  );
}
