export default function Contact() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">Contact Us</h1>
      <p className="mt-4">Email us at <a href="mailto:erickowiro6@gmail.com" className="text-blue-600 underline">erickowiro6@gmail.com</a></p>
    </div>
  );
}
